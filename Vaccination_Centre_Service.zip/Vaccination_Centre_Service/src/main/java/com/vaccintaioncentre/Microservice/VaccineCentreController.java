package com.vaccintaioncentre.Microservice;

import org.apache.catalina.LifecycleState;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;

@RestController
public class VaccineCentreController {


    @Autowired
    VaccineCentreRepository vaccineCentreRepository;

    @Autowired
    RestTemplate restTemplate;

    @RequestMapping("/")
    private String welcome(){
        return "Welcome Vaccine Centre";
    }

    @PostMapping(value = "/addcenter")
    private String addvaccinecenter(@RequestBody VaccineCentreEntity vaccineCentreEntity){

        vaccineCentreRepository.save(vaccineCentreEntity);

        return  "Saved";
    }

    @GetMapping(value = "/getallvaccinecenters")
    private List<VaccineCentreEntity> getallvaccinecenters(){

        List<VaccineCentreEntity> vaccineCentreEntities  = vaccineCentreRepository.findAll();

        return  vaccineCentreEntities;

    }


    @GetMapping(value = "/getserverdata/{id}")
    private  List<CitizenVacinationCentreResponse> getallinformation(@PathVariable int id){

        CitizenVacinationCentreResponse citizenVacinationCentreResponse  = new CitizenVacinationCentreResponse();

        //getvaccination center detail

        VaccineCentreEntity vaccineCentreEntity  = vaccineCentreRepository.findById(id).get();

        citizenVacinationCentreResponse.setVaccineCentre(vaccineCentreEntity);

        //restTemplate.getForObject("http://CITIZEN-SERVICE/getcitizens/"+id,List.class);

         List<CitizenEntity>  listofcitizens  =restTemplate.getForObject("http://CITIZEN-SERVICE/getcitizens/"+id,List.class);

                 citizenVacinationCentreResponse.setCitizenEntities(listofcitizens);



     return Collections.singletonList(citizenVacinationCentreResponse);

    }

}
