package com.vaccintaioncentre.Microservice;

import org.springframework.data.jpa.repository.JpaRepository;

public interface VaccineCentreRepository extends JpaRepository<VaccineCentreEntity,Integer> {

}
