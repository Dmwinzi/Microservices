package com.vaccintaioncentre.Microservice;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CitizenVacinationCentreResponse {

    private  VaccineCentreEntity vaccineCentre;
    private List<CitizenEntity> citizenEntities;


}
