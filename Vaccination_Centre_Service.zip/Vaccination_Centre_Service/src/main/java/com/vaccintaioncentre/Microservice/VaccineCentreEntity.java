package com.vaccintaioncentre.Microservice;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "vaccinecenters")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VaccineCentreEntity {

    @Id
    int id;

    @Column
    String centername;

    @Column
    String address;


}
