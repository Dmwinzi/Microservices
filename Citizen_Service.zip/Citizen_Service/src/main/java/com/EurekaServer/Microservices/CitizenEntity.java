package com.EurekaServer.Microservices;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity(name = "citizens")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CitizenEntity {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    int id;

    @Column
    String name;

    @Column
    int vaccinationcentreid;


}
