package com.EurekaServer.Microservices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CitizenController {


    @Autowired
    CitizenRepository citizenRepository;

    @RequestMapping("/")
    public String welcome(){
        return "Welcome Citizen";
    }

    @PostMapping(value = "/save")
    public  String savecitizen(@RequestBody CitizenEntity citizenEntity ){

        citizenRepository.save(citizenEntity);

        return "Saved";

    }

    @GetMapping(value = "/getcitizens/{vaccinationcentreid}")
    public  List<CitizenEntity> getcitizens(@PathVariable Integer vaccinationcentreid){

        List<CitizenEntity> citizenEntity  = citizenRepository.findbyvaccinationcentreid(vaccinationcentreid);

        return citizenEntity;

    }



}
